#!/bin/bash
# usage: run.sh <engine> <cond> <rep>
cd "$(dirname "$0")"; e=$1; c=$2; r=$3; o=outputs/$e-$c-$r.txt
case $e in
  haiku|sonnet) timeout 300 claude -p --model $e --tools "" --no-session-persistence < $c.txt > $o 2>/dev/null ;;
  *) timeout 360 agon ask $e --quiet --timeout 300 "$(cat $c.txt)" > $o 2>/dev/null ;;
esac
echo "$e $c $r rc=$? bytes=$(wc -c < $o)"
