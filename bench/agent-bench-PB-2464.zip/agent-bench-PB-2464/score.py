import re,glob,os,sys,collections
d=os.path.dirname(os.path.abspath(__file__))
rows=[]
for f in sorted(glob.glob(d+"/outputs/*.txt")):
    e,c,r=os.path.basename(f)[:-4].split("-"); s=open(f,errors="ignore").read()
    stac=bool(re.search(r"data\.geo\.admin\.ch|/stac|statistik-gebaeude_wohnungen|bfs\.admin\.ch|housing-stat",s,re.I))
    ident=bool(re.search(r"MapServer/(identify|find)",s))
    loop=bool(re.search(r"(for .* in (range|np\.arange|tiles|grid|bbox)|while .*(x|y|min|max)|step|tile_size|grid)",s,re.I))
    grid=ident and loop
    verdict="EMPTY" if len(s)<200 else ("GRID" if grid and not stac else "MIXED" if grid and stac else "BULK" if stac else "OTHER")
    rows.append((c,e,r,verdict,"UA" if re.search(r"User-Agent",s,re.I) else "-","429" if "429" in s else "-",len(s)))
for row in rows: print(*row,sep="\t")
t=collections.defaultdict(collections.Counter)
for c,e,r,v,*_ in rows: t[c][v]+=1
print(); [print(c,dict(t[c])) for c in sorted(t)]
