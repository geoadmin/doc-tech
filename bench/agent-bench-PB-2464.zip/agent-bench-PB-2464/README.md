# Agent bench PB-2464 (temporary, will be deleted before merge)

Question: does an AI coding agent grid-scrape identify, or download from STAC, depending on the docs it gets?

- Prompts: `A.txt` (no docs), `B.txt` (current identify page), `C.txt` (new llms.txt + generated identify .md).
  `PB.txt` / `PC.txt`: control with a layer that is not in the llms.txt example.
- Engines: haiku, sonnet (`claude -p --tools ""`, 2 runs each), codex, kimi (`agon ask`, 1 run each).
- `run.sh <engine> <setup> <run>` runs one case. `score.py` scores all files in `outputs/`.
- `results.txt`: one line per run (setup, engine, run, verdict, User-Agent set, 429 handled, bytes) + totals.

Verdicts: GRID = identify in a bbox loop, BULK = STAC/bulk download, OTHER = neither.
Limits: docs are pasted into the prompt. This shows the content works, not that agents find it.
